export const faqsData = [
    {
      id: 1,
      title: "How can we reach you?",
      desc: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Corporis dicta nihil neque molestias cupiditate obcaecati officiis magnam numquam iure doloremque.",
    },
    {
      id: 2,
      title: "When you are available?",
      desc: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Corporis dicta nihil neque molestias cupiditate obcaecati officiis magnam numquam iure doloremque.",
    },
    {
      id: 3,
      title: "How can I make an appointment?",
      desc: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Corporis dicta nihil neque molestias cupiditate obcaecati officiis magnam numquam iure doloremque.",
    },
    {
      id: 4,
      title: "Where can I get all the information?",
      desc: "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Corporis dicta nihil neque molestias cupiditate obcaecati officiis magnam numquam iure doloremque.",
    },
  ];
