import React from 'react';
import FAQS from "./Components/FAQ/FAQS"

export default function App() {
  return (<>
    <FAQS />
  </>
  );
}